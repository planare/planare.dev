export interface User {
  name: string;
  email: string;
  avatar: string | null;
  settings: {
    currency: string;
    theme: "light" | "dark";
    notifications: boolean;
  };
}

export interface Invoice {
  id: string;
  number: string;
  client: string;
  amount: number;
  status: "draft" | "pending" | "paid";
  date: string;
  dueDate: string;
} 