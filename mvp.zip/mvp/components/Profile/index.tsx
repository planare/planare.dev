/* eslint-disable @next/next/no-img-element */
"use client";

import { CameraIcon, UpdateIcon } from "@radix-ui/react-icons";
import { JSX, useRef, useState } from "react";

import { type User } from "../../types";

import styles from "./Profile.module.scss";

import { Button } from "@/ui/Button";
import { Input } from "@/ui/Input";
import { useToast } from "@/ui/Toast";

interface ProfileProps {
  setUser: (user: User) => void;
  user: User;
}

export function Profile({ user, setUser }: ProfileProps): JSX.Element {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email
  });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const file = e.target.files?.[0];

    if (!file) return;

    const reader = new FileReader();

    reader.onloadend = (): void => {
      setUser({ ...user, avatar: reader.result as string });
      toast({
        title: "Avatar Updated",
        description: "Your profile photo has been updated",
        variant: "success"
      });
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    setUser({ ...user, ...formData });
    setIsEditing(false);
    toast({
      title: "Profile Updated",
      description: "Your profile information has been saved",
      variant: "success"
    });
  };

  return (
    <div className={styles.wrapper}>
      <div className={styles.header}>
        <h1 className={styles.title}>Profile</h1>
        <p className={styles.subtitle}>Manage your account information</p>
      </div>

      <div className={styles.content}>
        <div className={styles.avatar}>
          <div className={styles.avatarImage}>
            {user.avatar ? (
              <img alt={user.name} src={user.avatar} />
            ) : (
              <div className={styles.avatarPlaceholder}>
                {user.name.charAt(0).toUpperCase()}
              </div>
            )}
            <Button 
              className={styles.avatarUpload}
              onClick={() => fileInputRef.current?.click()}
            >
              <CameraIcon />
            </Button>
          </div>
          <input
            ref={fileInputRef}
            accept="image/*"
            className={styles.fileInput}
            type="file"
            onChange={handleAvatarUpload}
          />
        </div>

        <form className={styles.form} onSubmit={handleSubmit}>
          <div className={styles.field}>
            <label htmlFor="name">Name</label>
            <Input
              disabled={!isEditing}
              id="name"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>

          <div className={styles.field}>
            <label htmlFor="email">Email</label>
            <Input
              disabled={!isEditing}
              id="email"
              required
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>

          <div className={styles.actions}>
            {isEditing ? (
              <>
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  Save Changes
                </Button>
              </>
            ) : (
              <Button onClick={() => setIsEditing(true)}>
                <UpdateIcon /> Edit Profile
              </Button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
} 