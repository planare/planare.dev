"use client";

import { 
  SunIcon, 
  MoonIcon, 
  BellIcon, 
  CheckIcon 
} from "@radix-ui/react-icons";
import { JSX } from "react";

import { type User } from "../../types";

import styles from "./Settings.module.scss";

import { Button } from "@/ui/Button";
import { Switch } from "@/ui/Switch";
import { useToast } from "@/ui/Toast";

interface SettingsProps {
  setUser: (user: User) => void;
  user: User;
}

const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
] as const;

export function Settings({ user, setUser }: SettingsProps): JSX.Element {
  const { toast } = useToast();

  const handleSettingChange = (
    key: keyof User["settings"], 
    value: string | boolean
  ): void => {
    setUser({
      ...user,
      settings: {
        ...user.settings,
        [key]: value
      }
    });

    toast({
      title: "Settings Updated",
      description: "Your preferences have been saved",
      variant: "success"
    });
  };

  return (
    <div className={styles.wrapper}>
      <div className={styles.header}>
        <h1 className={styles.title}>Settings</h1>
        <p className={styles.subtitle}>Customize your account preferences</p>
      </div>

      <div className={styles.content}>
        <section className={styles.section}>
          <h2>Appearance</h2>
          <div className={styles.themeSelector}>
            <Button
              className={`${styles.themeButton} ${user.settings.theme === "light" ? styles.active : ""}`}
              onClick={() => handleSettingChange("theme", "light")}
            >
              <SunIcon />
              Light
              {user.settings.theme === "light" && (
                <span className={styles.activeIndicator}>
                  <CheckIcon />
                </span>
              )}
            </Button>
            <Button
              className={`${styles.themeButton} ${user.settings.theme === "dark" ? styles.active : ""}`}
              onClick={() => handleSettingChange("theme", "dark")}
            >
              <MoonIcon />
              Dark
              {user.settings.theme === "dark" && (
                <span className={styles.activeIndicator}>
                  <CheckIcon />
                </span>
              )}
            </Button>
          </div>
        </section>

        <section className={styles.section}>
          <h2>Currency</h2>
          <div className={styles.currencySelector}>
            {currencies.map((currency) => (
              <Button
                key={currency.code}
                className={`${styles.currencyButton} ${
                  user.settings.currency === currency.code ? styles.active : ""
                }`}
                onClick={() => handleSettingChange("currency", currency.code)}
              >
                <span className={styles.currencySymbol}>{currency.symbol}</span>
                <span className={styles.currencyDetails}>
                  <span className={styles.currencyCode}>{currency.code}</span>
                  <span className={styles.currencyName}>{currency.name}</span>
                </span>
                {user.settings.currency === currency.code && (
                  <span className={styles.activeIndicator}>
                    <CheckIcon />
                  </span>
                )}
              </Button>
            ))}
          </div>
        </section>

        <section className={styles.section}>
          <h2>Notifications</h2>
          <div className={styles.notificationSetting}>
            <div className={styles.settingInfo}>
              <BellIcon />
              <div>
                <h3>Email Notifications</h3>
                <p>Receive updates about your invoices and payments</p>
              </div>
            </div>
            <Switch
              checked={user.settings.notifications}
              onCheckedChange={(checked) => 
                handleSettingChange("notifications", checked)
              }
            />
          </div>
        </section>
      </div>
    </div>
  );
} 