"use client";

import { 
  PlusIcon, 
  DotsHorizontalIcon,
  TrashIcon,
  CheckIcon,
  CrossCircledIcon,
  CheckCircledIcon,
  BarChartIcon,
  ClockIcon,
  Pencil1Icon} from "@radix-ui/react-icons";
import { JSX } from "react";

import { type Invoice } from "../../types";
import { formatCurrency } from "../../utils/formatCurrency";

import { CreateInvoice } from "./CreateInvoice";
import { EditInvoice } from "./EditInvoice";
import styles from "./Invoices.module.scss";

import { Badge } from "@/ui/Badge";
import { Button } from "@/ui/Button";
import { Dropdown } from "@/ui/Dropdown";
import { useToast } from "@/ui/Toast";

interface InvoicesProps {
  currency: string;
  editingInvoice: Invoice | null;
  invoices: Invoice[];
  setEditingInvoice: (invoice: Invoice | null) => void;
  setInvoices: (invoices: Invoice[]) => void;
  setView: (view: "list" | "create" | "edit") => void;
  view: "list" | "create" | "edit";
}

const actionDropdownItems = [
  { title: "Edit", href: "#", icon: <Pencil1Icon />, id: "edit" },
  { title: "Mark as Paid", href: "#", icon: <CheckIcon />, id: "mark-paid" },
  { title: "Delete", href: "#", icon: <TrashIcon />, id: "delete" }
];

export function Invoices({ 
  invoices, 
  setInvoices, 
  currency,
  view,
  setView,
  editingInvoice,
  setEditingInvoice 
}: InvoicesProps): JSX.Element {
  const { toast } = useToast();

  const totalAmount = invoices.reduce((sum, inv) => sum + inv.amount, 0);
  const paidAmount = invoices.filter(inv => inv.status === "paid").reduce((sum, inv) => sum + inv.amount, 0);
  const pendingAmount = invoices.filter(inv => inv.status === "pending").reduce((sum, inv) => sum + inv.amount, 0);

  const metrics = [
    { label: "Total", value: formatCurrency(totalAmount, currency), icon: BarChartIcon },
    { label: "Paid", value: formatCurrency(paidAmount, currency), icon: CheckCircledIcon },
    { label: "Pending", value: formatCurrency(pendingAmount, currency), icon: ClockIcon }
  ];

  const handleAction = (action: string, invoice: Invoice): void => {
    switch (action) {
      case "Edit":
        setEditingInvoice(invoice);
        setView("edit");
        break;
      case "Mark as Paid":
        setInvoices(invoices.map((i) => i.id === invoice.id ? { ...i, status: "paid" } : i));
        toast({ title: "Invoice marked as paid", variant: "success" });
        break;
      case "Delete":
        setInvoices(invoices.filter((i) => i.id !== invoice.id));
        toast({ title: "Invoice deleted", variant: "error" });
        break;
    }
  };

  if (view === "create") {
    return <CreateInvoice currency={currency} onBack={() => setView("list")} onCreate={(invoice) => {
      setInvoices([...invoices, invoice]);
      setView("list");
      toast({ title: "Invoice created", variant: "success" });
    }} />;
  }

  if (view === "edit" && editingInvoice) {
    return <EditInvoice 
      currency={currency} 
      invoice={editingInvoice}
      onBack={() => {
        setView("list");
        setEditingInvoice(null);
      }}
      onSave={(updatedInvoice) => {
        setInvoices(invoices.map(inv => 
          inv.id === updatedInvoice.id ? updatedInvoice : inv
        ));
        setView("list");
        setEditingInvoice(null);
        toast({ title: "Invoice updated", variant: "success" });
      }}
    />;
  }

  return (
    <div className={styles.wrapper}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Invoices</h1>
          <p className={styles.subtitle}>Manage your invoices and payments</p>
        </div>
        <Button onClick={() => setView("create")}>
          <PlusIcon /> New Invoice
        </Button>
      </div>

      <div className={styles.metrics}>
        {metrics.map((metric) => (
          <div key={metric.label} className={styles.metric}>
            <metric.icon />
            <div>
              <div className={styles.metricLabel}>{metric.label}</div>
              <div className={styles.metricValue}>{metric.value}</div>
            </div>
          </div>
        ))}
      </div>

      <div className={styles.list}>
        {invoices.map((invoice) => (
          <div key={invoice.id} className={styles.invoice}>
            <div className={styles.invoiceMain}>
              <div className={styles.invoiceHeader}>
                <div className={styles.invoiceNumber}>#{invoice.number}</div>
                <Badge variant={invoice.status === "paid" ? "success" : "default"}>
                  {invoice.status === "paid" ? (
                    <><CheckCircledIcon /> Paid</>
                  ) : (
                    <><CrossCircledIcon /> Pending</>
                  )}
                </Badge>
              </div>
              <div className={styles.invoiceDetails}>
                <div className={styles.client}>{invoice.client}</div>
                <div className={styles.amount}>{formatCurrency(invoice.amount, currency)}</div>
              </div>
            </div>
            <div className={styles.invoiceActions}>
              <div className={styles.dates}>
                <div>Created: {new Date(invoice.date).toLocaleDateString()}</div>
                <div>Due: {new Date(invoice.dueDate).toLocaleDateString()}</div>
              </div>
              <Dropdown 
                items={actionDropdownItems}
                onSelect={(item) => handleAction(item.title, invoice)}
              >
                <Button className={styles.actionTrigger} variant="ghost">
                  <DotsHorizontalIcon />
                </Button>
              </Dropdown>
            </div>
          </div>
        ))}
        
        {invoices.length === 0 && (
          <div className={styles.empty}>
            <p>No invoices yet</p>
            <Button variant="outline" onClick={() => setView("create")}>
              Create your first invoice
            </Button>
          </div>
        )}
      </div>
    </div>
  );
} 