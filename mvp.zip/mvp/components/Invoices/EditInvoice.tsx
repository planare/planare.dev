"use client";

import { ChevronLeftIcon } from "@radix-ui/react-icons";
import { JSX, useState } from "react";

import { type Invoice } from "../../types";

import styles from "./Form.module.scss";

import { Button } from "@/ui/Button";
import { Input } from "@/ui/Input";

interface EditInvoiceProps {
  currency: string;
  invoice: Invoice;
  onBack: () => void;
  onSave: (invoice: Invoice) => void;
}

export function EditInvoice({ 
  currency, 
  invoice, 
  onBack, 
  onSave 
}: EditInvoiceProps): JSX.Element {
  const [formData, setFormData] = useState(() => ({
    client: invoice.client,
    amount: invoice.amount.toString(),
    dueDate: new Date(invoice.dueDate).toISOString().split('T')[0],
    status: invoice.status
  }));

  return (
    <div className={styles.wrapper}>
      <div className={styles.header}>
        <Button variant="ghost" onClick={onBack}>
          <ChevronLeftIcon /> Back to Invoices
        </Button>
        <h1>Edit Invoice #{invoice.number}</h1>
      </div>

      <form 
        className={styles.form} 
        onSubmit={(e) => {
          e.preventDefault();
          onSave({
            ...invoice,
            client: formData.client,
            amount: parseFloat(formData.amount),
            dueDate: new Date(formData.dueDate).toISOString(),
            status: formData.status as "pending" | "paid"
          });
        }}
      >
        <div className={styles.field}>
          <label htmlFor="client">Client Name</label>
          <Input
            id="client"
            required
            value={formData.client}
            onChange={(e) => setFormData({ ...formData, client: e.target.value })}
          />
        </div>

        <div className={styles.field}>
          <label htmlFor="amount">Amount ({currency})</label>
          <Input
            id="amount"
            min="0"
            required
            step="0.01"
            type="number"
            value={formData.amount}
            onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
          />
        </div>

        <div className={styles.field}>
          <label htmlFor="dueDate">Due Date</label>
          <Input
            id="dueDate"
            required
            type="date"
            value={formData.dueDate}
            onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
          />
        </div>

        <div className={styles.field}>
          <label htmlFor="status">Status</label>
          <select
            id="status"
            value={formData.status}
            onChange={(e) => setFormData({ ...formData, status: e.target.value as "pending" | "paid" })}
          >
            <option value="pending">Pending</option>
            <option value="paid">Paid</option>
          </select>
        </div>

        <div className={styles.actions}>
          <Button type="button" variant="outline" onClick={onBack}>
            Cancel
          </Button>
          <Button type="submit">
            Save Changes
          </Button>
        </div>
      </form>
    </div>
  );
} 