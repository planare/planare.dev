"use client";

import { ChevronLeftIcon } from "@radix-ui/react-icons";
import { JSX, useState } from "react";

import { type Invoice } from "../../types";

import styles from "./Form.module.scss";

import { Button } from "@/ui/Button";
import { Input } from "@/ui/Input";

interface CreateInvoiceProps {
  currency: string;
  onBack: () => void;
  onCreate: (invoice: Invoice) => void;
}

export function CreateInvoice({ currency, onBack, onCreate }: CreateInvoiceProps): JSX.Element {
  const [formData, setFormData] = useState({
    client: "",
    amount: "",
    dueDate: ""
  });

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    
    const invoice: Invoice = {
      id: Math.random().toString(36).slice(2),
      number: `INV-${Math.floor(Math.random() * 10000)}`,
      client: formData.client,
      amount: parseFloat(formData.amount),
      status: "pending",
      date: new Date().toISOString(),
      dueDate: new Date(formData.dueDate).toISOString()
    };

    onCreate(invoice);
  };

  return (
    <div className={styles.wrapper}>
      <div className={styles.header}>
        <Button variant="ghost" onClick={onBack}>
          <ChevronLeftIcon /> Back to Invoices
        </Button>
        <h1>Create Invoice</h1>
      </div>

      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.field}>
          <label htmlFor="client">Client Name</label>
          <Input
            id="client"
            required
            value={formData.client}
            onChange={(e) => setFormData({ ...formData, client: e.target.value })}
          />
        </div>

        <div className={styles.field}>
          <label htmlFor="amount">Amount ({currency})</label>
          <Input
            id="amount"
            min="0"
            required
            step="0.01"
            type="number"
            value={formData.amount}
            onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
          />
        </div>

        <div className={styles.field}>
          <label htmlFor="dueDate">Due Date</label>
          <Input
            id="dueDate"
            required
            type="date"
            value={formData.dueDate}
            onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
          />
        </div>

        <div className={styles.actions}>
          <Button type="button" variant="outline" onClick={onBack}>
            Cancel
          </Button>
          <Button type="submit">
            Create Invoice
          </Button>
        </div>
      </form>
    </div>
  );
} 