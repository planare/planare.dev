/* eslint-disable @next/next/no-img-element */
"use client";

import { 
  ReaderIcon, 
  PersonIcon, 
  GearIcon, 
  ExitIcon 
} from "@radix-ui/react-icons";
import { JSX } from "react";

import { type User } from "../../types";

import styles from "./Navigation.module.scss";

import { Button } from "@/ui/Button";
import { Dropdown } from "@/ui/Dropdown";
import { cn } from "@/utils/cn";

interface NavigationProps {
  activeView: "invoices" | "profile" | "settings";
  setActiveView: (view: "invoices" | "profile" | "settings") => void;
  user: User;
}

const navItems = [
  { id: "invoices", label: "Invoices", icon: ReaderIcon },
  { id: "profile", label: "Profile", icon: PersonIcon },
  { id: "settings", label: "Settings", icon: GearIcon },
] as const;

const userDropdownItems = [
  { title: "Sign out", href: "#", icon: <ExitIcon /> }
];

export function Navigation({ activeView, setActiveView, user }: NavigationProps): JSX.Element {
  return (
    <div className={styles.navigation}>
      <div className={styles.header}>
        <Dropdown items={userDropdownItems}>
          <Button className={styles.avatar}>
            {user.avatar ? (
              <img alt={user.name} src={user.avatar} />
            ) : (
              <PersonIcon />
            )}
          </Button>
        </Dropdown>
        <div className={styles.userInfo}>
          <div className={styles.name}>{user.name}</div>
          <div className={styles.email}>{user.email}</div>
        </div>
      </div>

      <nav className={styles.nav}>
        {navItems.map(({ id, label, icon: Icon }) => (
          <Button
            key={id}
            className={cn(
              styles.navItem,
              activeView === id && styles.active
            )}
            onClick={() => setActiveView(id)}
          >
            <Icon />
            {label}
          </Button>
        ))}
      </nav>
    </div>
  );
} 