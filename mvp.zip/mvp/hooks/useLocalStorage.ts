/* eslint-disable no-console */
"use client";

import { useState, useEffect } from "react";

import { Invoice } from "../types";

export const DEFAULT_INVOICES: Invoice[] = [
  {
    id: "inv-1",
    number: "INV-2024-001",
    client: "Acme Corp",
    amount: 2500.00,
    status: "paid",
    date: "2024-01-15T00:00:00.000Z",
    dueDate: "2024-02-15T00:00:00.000Z"
  },
  {
    id: "inv-2",
    number: "INV-2024-002",
    client: "Globex Inc",
    amount: 1750.50,
    status: "pending",
    date: "2024-02-01T00:00:00.000Z",
    dueDate: "2024-03-01T00:00:00.000Z"
  },
  {
    id: "inv-3",
    number: "INV-2024-003",
    client: "TechStart Ltd",
    amount: 5000.00,
    status: "paid",
    date: "2024-02-10T00:00:00.000Z",
    dueDate: "2024-03-10T00:00:00.000Z"
  }
];

export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T) => void] {
  const [storedValue, setStoredValue] = useState<T>(() => {
    if (typeof window === "undefined") return initialValue;

    try {
      const item = window.localStorage.getItem(key);

      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(error);

      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(storedValue));
    } catch (error) {
      console.error(error);
    }
  }, [key, storedValue]);

  return [storedValue, setStoredValue] as const;
} 