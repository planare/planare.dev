"use client";

import { AnimatePresence, motion } from "framer-motion";
import { JSX, useState } from "react";

import { Invoices } from "./components/Invoices";
import { Navigation } from "./components/Navigation";
import { Profile } from "./components/Profile";
import { Settings } from "./components/Settings";
import { DEFAULT_INVOICES, useLocalStorage } from "./hooks/useLocalStorage";
import styles from "./mvp.module.scss";
import { type User, type Invoice } from "./types";

export function MinimumViableProduct(): JSX.Element {
  const [activeView, setActiveView] = useState<"invoices" | "profile" | "settings">("invoices");
  const [invoiceView, setInvoiceView] = useState<"list" | "create" | "edit">("list");
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  
  const [user, setUser] = useLocalStorage<User>("mvp-user", {
    name: "Alex Smith",
    email: "alex@example.com",
    avatar: null,
    settings: {
      currency: "USD",
      theme: "light",
      notifications: true
    }
  });

  const [invoices, setInvoices] = useLocalStorage<Invoice[]>("mvp-invoices", DEFAULT_INVOICES);

  return (
    <div className={styles.wrapper}>
      <div className={styles.container}>
        <Navigation 
          activeView={activeView} 
          setActiveView={(view) => {
            setActiveView(view);
            setInvoiceView("list");
            setEditingInvoice(null);
          }}
          user={user}
        />
        
        <div className={styles.content}>
          <AnimatePresence initial={false} mode="wait">
            <motion.div 
              key={`${activeView}-${invoiceView}`}
              animate={{ opacity: 1 }}
              className={styles.view}
              exit={{ opacity: 0 }}
              initial={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              {activeView === "invoices" && (
                <Invoices 
                  currency={user.settings.currency} 
                  editingInvoice={editingInvoice}
                  invoices={invoices}
                  setEditingInvoice={setEditingInvoice}
                  setInvoices={setInvoices}
                  setView={setInvoiceView}
                  view={invoiceView}
                />
              )}
              {activeView === "profile" && (
                <Profile 
                  setUser={setUser} 
                  user={user} 
                />
              )}
              {activeView === "settings" && (
                <Settings 
                  setUser={setUser} 
                  user={user} 
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
} 